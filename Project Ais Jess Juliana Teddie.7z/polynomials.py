from QRprepData_ak import *

def AlphaToInt(alpha):
    '''Takes in a number, alpha, and returns the corresponding integer value.'''
    alph1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255]
    int1 = [1, 2, 4, 8, 16, 32, 64, 128, 29, 58, 116, 232, 205, 135, 19, 38, 76, 152, 45, 90, 180, 117, 234, 201, 143, 3, 6, 12, 24, 48, 96, 192, 157, 39, 78, 156, 37, 74, 148, 53, 106, 212, 181, 119, 238, 193, 159, 35, 70, 140, 5, 10, 20, 40, 80, 160, 93, 186, 105, 210, 185, 111, 222, 161, 95, 190, 97, 194, 153, 47, 94, 188, 101, 202, 137, 15, 30, 60, 120, 240, 253, 231, 211, 187, 107, 214, 177, 127, 254, 225, 223, 163, 91, 182, 113, 226, 217, 175, 67, 134, 17, 34, 68, 136, 13, 26, 52, 104, 208, 189, 103, 206, 129, 31, 62, 124, 248, 237, 199, 147, 59, 118, 236, 197, 151, 51, 102, 204, 133, 23, 46, 92, 184, 109, 218, 169, 79, 158, 33, 66, 132, 21, 42, 84, 168, 77, 154, 41, 82, 164, 85, 170, 73, 146, 57, 114, 228, 213, 183, 115, 230, 209, 191, 99, 198, 145, 63, 126, 252, 229, 215, 179, 123, 246, 241, 255, 227, 219, 171, 75, 150, 49, 98, 196, 149, 55, 110, 220, 165, 87, 174, 65, 130, 25, 50, 100, 200, 141, 7, 14, 28, 56, 112, 224, 221, 167, 83, 166, 81, 162, 89, 178, 121, 242, 249, 239, 195, 155, 43, 86, 172, 69, 138, 9, 18, 36, 72, 144, 61, 122, 244, 245, 247, 243, 251, 235, 203, 139, 11, 22, 44, 88, 176, 125, 250, 233, 207, 131, 27, 54, 108, 216, 173, 71, 142, 1]
    alph_to_int = dict(zip(alph1,int1))
    return alph_to_int[alpha]

def IntToAlpha(integer):
    '''Takes in a number, integer, and returns the corresponding alpha value.'''
    alph2 = [0, 1, 25, 2, 50, 26, 198, 3, 223, 51, 238, 27, 104, 199, 75, 4, 100, 224, 14, 52, 141, 239, 129, 28, 193, 105, 248, 200, 8, 76, 113, 5, 138, 101, 47, 225, 36, 15, 33, 53, 147, 142, 218, 240, 18, 130, 69, 29, 181, 194, 125, 106, 39, 249, 185, 201, 154, 9, 120, 77, 228, 114, 166, 6, 191, 139, 98, 102, 221, 48, 253, 226, 152, 37, 179, 16, 145, 34, 136, 54, 208, 148, 206, 143, 150, 219, 189, 241, 210, 19, 92, 131, 56, 70, 64, 30, 66, 182, 163, 195, 72, 126, 110, 107, 58, 40, 84, 250, 133, 186, 61, 202, 94, 155, 159, 10, 21, 121, 43, 78, 212, 229, 172, 115, 243, 167, 87, 7, 112, 192, 247, 140, 128, 99, 13, 103, 74, 222, 237, 49, 197, 254, 24, 227, 165, 153, 119, 38, 184, 180, 124, 17, 68, 146, 217, 35, 32, 137, 46, 55, 63, 209, 91, 149, 188, 207, 205, 144, 135, 151, 178, 220, 252, 190, 97, 242, 86, 211, 171, 20, 42, 93, 158, 132, 60, 57, 83, 71, 109, 65, 162, 31, 45, 67, 216, 183, 123, 164, 118, 196, 23, 73, 236, 127, 12, 111, 246, 108, 161, 59, 82, 41, 157, 85, 170, 251, 96, 134, 177, 187, 204, 62, 90, 203, 89, 95, 176, 156, 169, 160, 81, 11, 245, 22, 235, 122, 117, 44, 215, 79, 174, 213, 233, 230, 231, 173, 232, 116, 214, 244, 234, 168, 80, 88, 175]
    int2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255]
    int_to_alph = dict(zip(int2,alph2))
    return int_to_alph[integer]

def PolyXOR(MultiplyResult, MessagePoly):
    '''Takes in two integer polynomials and returns an integer polynomial for which the
    coefficients are the bitwise XORS of the two original polynomial coefficients.'''
    newcoeff = []
    for i in range(len(MultiplyResult.coeff)):
        if (i+1) > len(MessagePoly.coeff):
            newcoeff.append(MultiplyResult.coeff[i])
        else:
            newcoeff.append(MultiplyResult.coeff[i]^MessagePoly.coeff[i])
    return Polynomial(newcoeff, MultiplyResult.order, 'Integers')

def AlphaMult(Generator, MultiplyBy):
    factor = IntToAlpha(MultiplyBy.coeff[0])
    newcoeff = []
    for alpha in Generator.coeff:
        res = factor + alpha
        res = res % 255
        newcoeff.append(res)
    return Polynomial(newcoeff, Generator.order, 'Alphas')

def ErrorProcess(Generator, Message):
    Result = AlphaMult(Generator, Message)
    Result.switchState() # Result now in int form
    Result = PolyXOR(Result,Message)
    Result.removeZeros()
    if Result.exp[-1] != 0:
        newOrder = Result.order
        Generator.changeOrder(newOrder)
        return ErrorProcess(Generator, Result)
    else:
        return Result.coeff

class Polynomial(object):
    '''Represents a polynomial. Must be declared w/ coefficients and exponents as lists and states as 'Alphas' or 'Integers'.'''

    def __init__(self, coefficients, exp_high, state):
        self.coeff = coefficients
        self.state = state
        self.order = exp_high
        exponents = []
        for i in range(len(self.coeff)):
            exponents.append(self.order-i)
        self.exp = exponents

    def __str__(self):
        res = []
        if self.state == 'Alphas':
            for i in range(len(self.coeff)):
                res.append('alpha^'+str(self.coeff[i])+'x^'+str(self.exp[i]))
        if self.state == 'Integers':
            for i in range(len(self.coeff)):
                res.append(str(self.coeff[i])+'x^'+str(self.exp[i]))
        return ' + '.join(res)

    def switchState(self):
        newcoeff = []
        if self.state == 'Alphas':
            for alph in self.coeff:
                newcoeff.append(AlphaToInt(alph))
            newstate = 'Integers'
        if self.state == 'Integers':
            for integ in self.coeff:
                newcoeff.append(IntToAlpha(integ))
            newstate = 'Alphas'
        self.coeff = newcoeff
        self.state = newstate

    def changeCoeff(self, newcoeff):
        self.coeff = newcoeff

    def removeZeros(self):
        if self.coeff[0] == 0:
            del self.coeff[0]
            del self.exp[0]
            self.order = self.order - 1
            self.removeZeros()

    def changeOrder(self, newOrder):
        diff = self.order - newOrder
        self.order = newOrder
        for exponent in self.exp:
            exponent = exponent - diff

def QRbitstring(text):
    # text is the string we want to encode
    alphanumeric = "0010" # Alpha-numeric mode 'b0010
    Generator = Polynomial([0,74,152,176,100,86,100,106,104,130,218,206,140,78],25,'Alphas')
    messageBits = GenerateMessage(alphanumeric, text)
    Message = Polynomial(messageBits, 25, 'Integers')
    errorCodes = ErrorProcess(Generator, Message)
    decimalBitstring = messageBits + errorCodes
    bitstring = ''
    for number in decimalBitstring:
            bitstring = bitstring + '{0:0>8b}'.format(number)
    return bitstring
